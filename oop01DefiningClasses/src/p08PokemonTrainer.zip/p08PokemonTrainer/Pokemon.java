package p08PokemonTrainer;

public class Pokemon {
	
	protected String name;
	protected String elemnet;
	protected Integer health;
	
	Pokemon(String name, String elemnet, Integer health) {
		this.name = name;
		this.elemnet = elemnet;
		this.health = health;
	}
}
