package p00LabShapes;

public class Main {
public static void main(String[] args) {
	
}
}
