package oop03Inheritance;

public class Cat extends Animal{
	void meow(){
		System.out.println("meowing...");
	}
}
