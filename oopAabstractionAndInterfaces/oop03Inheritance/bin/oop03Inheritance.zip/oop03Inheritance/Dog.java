package oop03Inheritance;

public class Dog extends Animal {

	protected void bark() {
		System.out.println("barking...");
	}
}
