package oop03Inheritance;

public class Puppy extends Dog{
	
	void weep(){
		System.out.println("weeping...");
	}
}
