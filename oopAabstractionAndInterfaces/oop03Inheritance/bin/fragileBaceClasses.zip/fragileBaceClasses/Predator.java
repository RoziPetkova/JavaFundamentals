package fragileBaceClasses;

public class Predator extends Animal {
	private int health = 0;
	
//	@Override
//	public void eat(Food food){
//		this.foodEaten.add(food);
//		this.health +=1;
//	}

	public int getHealth() {
		return health;
	}	
}
