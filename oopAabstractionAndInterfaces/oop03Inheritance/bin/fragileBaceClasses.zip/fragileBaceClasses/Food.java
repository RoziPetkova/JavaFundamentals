package fragileBaceClasses;

public class Food {

}
