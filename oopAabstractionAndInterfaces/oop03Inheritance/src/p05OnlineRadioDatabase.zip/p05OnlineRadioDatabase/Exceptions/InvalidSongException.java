package p05OnlineRadioDatabase.Exceptions;

public class InvalidSongException extends Exception{
	
	public InvalidSongException(String exception){
		super(exception);
	}
}
