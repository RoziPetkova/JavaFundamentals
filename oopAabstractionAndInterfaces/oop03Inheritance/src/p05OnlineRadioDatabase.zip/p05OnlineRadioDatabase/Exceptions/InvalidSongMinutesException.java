package p05OnlineRadioDatabase.Exceptions;

public class InvalidSongMinutesException extends InvalidSongLengthException{
	public InvalidSongMinutesException(String exception){
		super(exception);
	}
}
