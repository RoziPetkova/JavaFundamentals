package p05OnlineRadioDatabase.Exceptions;

public class InvalidSongSecondsException extends InvalidSongLengthException {
	public InvalidSongSecondsException(String exception) {
		super(exception);
	}
}
