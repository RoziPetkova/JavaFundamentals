package p05OnlineRadioDatabase.Exceptions;

public class InvalidSongNameException extends InvalidSongException {
	public InvalidSongNameException(String exception) {
		super(exception);
	}
}
