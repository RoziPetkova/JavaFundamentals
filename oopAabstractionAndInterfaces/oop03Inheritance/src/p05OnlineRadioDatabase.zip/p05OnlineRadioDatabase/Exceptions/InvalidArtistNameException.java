package p05OnlineRadioDatabase.Exceptions;

public class InvalidArtistNameException extends InvalidSongException {
	public InvalidArtistNameException(String exception){
		super(exception);
	}
}
