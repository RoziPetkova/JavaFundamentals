package p05OnlineRadioDatabase.Exceptions;

public class InvalidSongLengthException extends InvalidSongException {
	
	public InvalidSongLengthException(String exception){
		super(exception);
	}
}
