package exercises.p01interfacePerson;

public interface Car {
	String BREAKS = "Brakes!";
	String PUSH_THE_GAS_PEDAL = "Zadu6avam sA!";
}
