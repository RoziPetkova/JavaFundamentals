package exercises.p01interfacePerson;

public interface Identifiable {
   String getID();
}
