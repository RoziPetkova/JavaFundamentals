package exercises.p01interfacePerson;

public interface Birthable extends Identifiable {
	String getBirthDay();
}
