package exercises.p01interfacePerson;

public interface Person extends Birthable{
	
	String getName();
	Integer getAge();
}
