package exercises.p01interfacePerson;

public class Citizen implements Birthable, Identifiable, Person{
	
	private String name;
	private String ID;
	private String birthDay;
	private Integer age;

	public Citizen(String name, Integer age, String ID, String birthDay) {
		this.name = name;
		this.age = age;
		this.ID = ID;
		this.birthDay = birthDay;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public Integer getAge() {
		return age;
	}

	@Override
	public String getID() {
		return ID;
	}

	@Override
	public String getBirthDay() {
		return birthDay;
	}
}
