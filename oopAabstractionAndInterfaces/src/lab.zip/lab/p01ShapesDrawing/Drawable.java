package lab.p01ShapesDrawing;

public interface Drawable {

	void draw();
}
