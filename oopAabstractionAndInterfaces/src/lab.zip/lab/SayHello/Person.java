package lab.SayHello;

public interface Person {
	
	String getName();	
	String sayHello();
}
