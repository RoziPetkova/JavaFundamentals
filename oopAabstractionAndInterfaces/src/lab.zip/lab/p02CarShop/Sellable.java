package lab.p02CarShop;

public interface Sellable extends Car{
	
	Double getPrice();
}
