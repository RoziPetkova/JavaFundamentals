package app.utilities;

public class Constants {
    private Constants() {
    }
    
    public static final String TERMINATING_COMMAND = "BEER IS COMING";
}
