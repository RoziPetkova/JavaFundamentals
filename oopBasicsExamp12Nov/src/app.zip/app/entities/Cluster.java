package app.entities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Cluster {

	private String id; 
	private int rows;
	private List<Cell> cells;

	public Cluster(String id, int rows, int cols) {
		if (rows > 0 && cols > 0) 
			this.id = id;
			this.rows = rows;
			this.cols = cols;
			this.cells = new ArrayList<>();	
	}

	public String getId() {
		return this.id;
	}

	public int getRows() {
		return rows;
	}

	public int getCols() {
		return cols;
	}

	private int cols;

	public List<Cell> getCells() {
		return Collections.unmodifiableList(this.cells);
	}

	public void addCell( Cell theCell){
		cells.add(theCell);
	}
	
	public boolean cellIsInsice(Cell theCell) {
		if(theCell.getPositionCol() > this.cols || theCell.getPositionRow() > this.rows)
			return false;
		return true;
	}
	
	public void activate() {
		Comparator <Cell> comp1 = (c1, c2) -> c1.getPositionRow() > c2.getPositionRow() ? 1 
				: c1.getPositionRow() < c2.getPositionRow() ? -1
				: 0;
		
		Collections.sort(cells, comp1);
		Cell theCell = cells.get(0);
		
		for (int i = 1; i < cells.size() ; i++) {
			theCell = theCell.metCell(theCell, cells.get(i));
			theCell.setPositionCol(cells.get(i).getPositionCol());
			theCell.setPositionRow(cells.get(i).getPositionRow());
		}
		cells.stream().filter(x -> x.getEnergy() < 0 || x.getHealth() < 0).forEach(x -> cells.remove(x));
	}
	
	@Override
	public String toString() {
		String cells = "";
		for (Cell cell : this.cells) {
			cells += cell.toString();
		}
		return String.format("\n----Cluster %s", this.id) + cells;
	}
}
